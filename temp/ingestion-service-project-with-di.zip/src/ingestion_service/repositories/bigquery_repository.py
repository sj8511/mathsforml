from google.cloud import bigquery

class BigQueryRepository:
    def __init__(self):
        self.client = bigquery.Client()

    def insert_rows(self, table_name, rows):
        table_id = f"your_project.your_dataset.{table_name}"
        errors = self.client.insert_rows_json(table_id, rows)
        if errors:
            raise RuntimeError(errors)

    def execute_query(self, query):
        query_job = self.client.query(query)
        results = query_job.result()
        return [dict(row.items()) for row in results]
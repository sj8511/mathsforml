from kafka import KafkaConsumer

def start_consumer(topic, bootstrap_servers, pipeline_service):
    consumer = KafkaConsumer(
        topic,
        bootstrap_servers=bootstrap_servers,
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        group_id="ingestion-group"
    )

    for message in consumer:
        pipeline_service.process(message.value)
from fastapi import FastAPI
from ingestion_service.api.data_routes import router

app = FastAPI(title="Ingestion Service with DI")

app.include_router(router)
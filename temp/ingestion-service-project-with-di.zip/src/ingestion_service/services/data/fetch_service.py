class FetchService:
    def __init__(self, repository):
        self.repository = repository

    def fetch(self, record_id: str):
        query = f"SELECT * FROM my_table WHERE id = '{record_id}'"
        return self.repository.execute_query(query)
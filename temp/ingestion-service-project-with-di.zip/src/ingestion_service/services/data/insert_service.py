class InsertService:
    def __init__(self, repository):
        self.repository = repository

    def insert(self, data: dict):
        if not data.get("id"):
            raise ValueError("ID is required")
        self.repository.insert_rows("my_table", [data])
        return {"status": "inserted"}
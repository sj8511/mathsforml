class PipelineService:
    def __init__(self, insert_service, fetch_service):
        self.insert_service = insert_service
        self.fetch_service = fetch_service

    def process(self, message: dict):
        transformed = self._transform(message)
        self.insert_service.insert(transformed)
        return self.fetch_service.fetch(transformed["id"])

    def _transform(self, message):
        return message
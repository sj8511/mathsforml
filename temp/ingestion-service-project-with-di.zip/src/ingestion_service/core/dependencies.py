from ingestion_service.repositories.bigquery_repository import BigQueryRepository
from ingestion_service.services.data.insert_service import InsertService
from ingestion_service.services.data.fetch_service import FetchService
from ingestion_service.services.orchestration.pipeline_service import PipelineService

def get_repository():
    return BigQueryRepository()

def get_insert_service():
    return InsertService(get_repository())

def get_fetch_service():
    return FetchService(get_repository())

def get_pipeline_service():
    return PipelineService(
        insert_service=get_insert_service(),
        fetch_service=get_fetch_service(),
    )
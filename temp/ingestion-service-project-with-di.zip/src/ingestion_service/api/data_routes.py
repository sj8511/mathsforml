from fastapi import APIRouter, Depends
from ingestion_service.models.data_models import InsertRequest
from ingestion_service.services.orchestration.pipeline_service import PipelineService
from ingestion_service.core.dependencies import get_pipeline_service

router = APIRouter()

@router.post("/insert")
def insert_data(
    request: InsertRequest,
    pipeline_service: PipelineService = Depends(get_pipeline_service),
):
    return pipeline_service.process(request.dict())
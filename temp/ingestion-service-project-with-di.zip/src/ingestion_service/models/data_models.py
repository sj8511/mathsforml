from pydantic import BaseModel

class InsertRequest(BaseModel):
    id: str
    name: str
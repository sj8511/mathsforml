import time

def retry(operation, retries=3, delay=2):
    for attempt in range(retries):
        try:
            return operation()
        except Exception:
            if attempt == retries - 1:
                raise
            time.sleep(delay)
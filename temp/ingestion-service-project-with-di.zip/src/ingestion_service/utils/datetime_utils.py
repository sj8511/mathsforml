from datetime import datetime, timezone

def current_utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()